# azure-app-service-python-flask-example

This is a lightweight Python Flask app including basic Kudu Deployment configuration for testing / validating Linux Web App deployments in MS Azure. 

**NOTE:** This app we created primarily for testing resource deployments of `azurerm_linux_web_app` in the Terraform AzureRM provider, for other usages YMMV.
