#!/usr/bin/env sh

pip install -r requirements.txt